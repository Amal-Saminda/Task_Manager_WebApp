const mongoose = require("mongoose");

const userSchema = new mongoose.Schema(

  {
    name : {type:String , required: true},
    email : {type: String , required: true , unique: true, lowercase: true , trim: true},
    password: {type: String , required: true},
    profileImageUrl: {type:String , default: null},
    role: {type:String , enum: ["admin" , "member"], default: "member"}, //role base access

  },
  {timestamps: true}

)

module.exports = mongoose.model("User" , userSchema);