import AppRoutes from "./AppRoutes";

export const PATHS = {
  LOGIN: '/login',
  SIGN_UP: '/SingUp',
  ADMIN_DASHBOARD: '/admin/dashboard',
  USER_DASHBOARD: '/user/dashboard',
};

export const ROLES = {
  ADMIN: 'admin',
  USER: 'user',
};

// 'ADMIN' / 'Admin' / 'admin' -> 'admin'. Anything else -> 'user'.
export const normalizeRole = (role) =>
  String(role ?? '').toLowerCase() === ROLES.ADMIN ? ROLES.ADMIN : ROLES.USER;

// Where each role lands after a successful login
export const getDashboardPath = (role) =>
  normalizeRole(role) === ROLES.ADMIN == AppRoutes.Dashboard;
